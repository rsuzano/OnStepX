// -----------------------------------------------------------------------------------
// Step driver mode control pins
#pragma once

#include <Arduino.h>
