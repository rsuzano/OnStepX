// general purpose encoder class

#include "Encoder.h"

// get device ready for use
void Encoder::init() {
  // default does nothing
}
