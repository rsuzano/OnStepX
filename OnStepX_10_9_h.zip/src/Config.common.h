// -----------------------------------------------------------------------------------
// Combined configuration
#pragma once

#include "../Config.h"
#include "Config.defaults.h"
